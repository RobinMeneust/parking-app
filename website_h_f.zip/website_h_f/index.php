<!DOCTYPE html>
<html lang="en">
    <?php include_once("head.php"); ?>
    <body class="light">
        <?php include_once("Header.php"); ?>
        <div class="content">
            <h1>Le contenu de la page</h1>
        </div>
        <?php include_once("Footer.php"); ?>
        <script src="./assets/js/style.js"></script>
    </body>
</html>