<header>
  <div class="logo">
    <a href="./index.php">PARK'O TOP</a>
  </div>
  <div class="search-bar">
    <form>
      <input type="text" placeholder="Rechercher...">
      <button type="submit">Rechercher</button>
    </form>
  </div>
  <div class="account">
    <a href="#">Se connecter</a>
  </div>
</header>