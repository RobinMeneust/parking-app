/* Test */

/*if(window.matchMedia && window.matchMedia('(prefers-color-system: dark)').matches) {
    alert('Wow je suis en Dark mode !')
}*/

/* Méthode 2 */

/*function themeNuitJour() {
    console.log("Hello");

    const date = new Date()
    const hour = date.getHours()

    if(hour > 8 || hour < 20) {
        document.documentElement.style.setProperty('--font', '#000')
        document.documentElement.style.setProperty('--background', '#fff')
    } else {
        document.documentElement.style.setProperty('--font', '#fff')
        document.documentElement.style.setProperty('--background', '#000')
    }
}

themeNuitJour()*/